from machine import Pin, ADC
from math import log
import time
import network
from umqtt.simple import MQTTClient

SSID = "Wokwi-GUEST"
PASSWORD = ""

MQTT_BROKER = "broker.hivemq.com"
CLIENT_ID = "esp32_client"
TOPIC_TEMP = b"ESP32/temp1"
TOPIC_MODE = b"ESP32/mode1"
TOPIC_THRESHOLD = b"ESP32/set_threshold1"

adc = ADC(Pin(34))
adc.width(ADC.WIDTH_10BIT)
adc.atten(ADC.ATTN_11DB)

relay = Pin(12, Pin.OUT)
led_warning = Pin(13, Pin.OUT)

DEFAULT_THRESHOLD = 35.0
current_threshold = DEFAULT_THRESHOLD
mode = "manual"  
manual_override = None  

def connect_wifi():
    wlan = network.WLAN(network.STA_IF)
    wlan.active(True)
    wlan.connect(SSID, PASSWORD)
    while not wlan.isconnected():
        time.sleep(0.5)
    print("WiFi connected:", wlan.ifconfig())

def on_message(topic, msg):
    global mode, current_threshold, manual_override
    topic_str = topic.decode()
    msg_str = msg.decode()
    print(f"[MQTT] {topic_str} → {msg_str}")

    if topic == TOPIC_MODE:
        if msg_str == "manual":
            mode = "manual"
            current_threshold = DEFAULT_THRESHOLD
            manual_override = None
            print("Mode set to MANUAL. Using default threshold:", DEFAULT_THRESHOLD)
        elif msg_str == "auto":
            mode = "auto"
            manual_override = None
            print("Mode set to AUTOMATIC. Waiting for threshold...")
        elif msg_str in ["on", "off"] and mode == "manual":
            manual_override = msg_str
            print(f"Manual override set: {manual_override}")
    elif topic == TOPIC_THRESHOLD and mode == "auto":
        try:
            current_threshold = float(msg_str)
            print("New auto threshold set to:", current_threshold)
        except ValueError:
            print("Invalid threshold received!")

def setup_mqtt():
    client = MQTTClient(CLIENT_ID, MQTT_BROKER)
    client.set_callback(on_message)
    client.connect()
    print("MQTT connected.")
    client.subscribe(TOPIC_MODE)
    client.subscribe(TOPIC_THRESHOLD)
    return client

connect_wifi()
client = setup_mqtt()

BETA = 3950

while True:
    client.check_msg()

    analog = adc.read()
    if analog == 0:
        continue

    celsius = 1 / (log(1 / (1023. / analog - 1)) / BETA + 1 / 298.15) - 273.15
    print(f"Temperature: {celsius:.1f} °C | Mode: {mode} | Threshold: {current_threshold}")

    if mode == "manual":
        if manual_override == "on":
            led_warning.on()
            relay.on()
            print("Manual override: FORCED ON")
        elif manual_override == "off":
            led_warning.off()
            relay.off()
            print("Manual override: FORCED OFF")
        else:
            if celsius >= current_threshold:
                led_warning.on()
                relay.on()
            else:
                led_warning.off()
                relay.off()

    elif mode == "auto":
        if celsius >= current_threshold:
            led_warning.on()
            relay.on()
        else:
            led_warning.off()
            relay.off()


    client.publish(TOPIC_TEMP, str(celsius).encode())
    time.sleep(2)
